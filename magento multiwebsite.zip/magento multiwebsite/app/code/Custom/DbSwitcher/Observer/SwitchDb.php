<?php
namespace Custom\DbSwitcher\Observer;

use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class SwitchDb implements ObserverInterface
{
    protected $request;
    protected $resource;

    public function __construct(
        RequestInterface $request,
        ResourceConnection $resource
    ) {
        $this->request = $request;
        $this->resource = $resource;
    }

    public function aroundGetConnection(
        \Magento\Framework\App\ResourceConnection $subject,
        \Closure $proceed,
        $name = null
    ) {
        $serverName = $this->request->getServer('SERVER_NAME');

        if ($serverName == 'test.magento.com') {
            $name = 'test';
        }

        return $proceed($name);
    }

    public function execute(Observer $observer)
    {
        // This method is required by the ObserverInterface but is not used in this context.
        // You can leave it empty or add some logging here for debugging purposes.
    }
}
